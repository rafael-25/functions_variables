import pytest
from tic-tac-toe import check_for_winner

def test_check_for_winner_keep_playing():
    board = [['X', ' ', 'O'],
             ['O', ' ', 'X'],
             [' ', ' ', ' ']]
    assert check_for_winner(board) == 'keep playing'

def test_check_for_winner_tie():
    board = [['X', 'O', 'X'],
             ['X', 'X', 'O'],
             ['O', 'X', 'O']]
    assert check_for_winner(board) == 'tie'

def test_check_for_winner_end_game():
    board = [['X', ' ', 'O'],
             ['X', 'O', 'X'],
             ['X', ' ', 'O']]
    assert check_for_winner(board) == 'X'

    board = [['X', ' ', 'O'],
             ['O', 'X', 'O'],
             ['X', ' ', 'O']]
    assert check_for_winner(board) == 'O'

    board = [['X', 'O', 'X'],
             ['O', 'X', 'O'],
             ['X', 'O', 'X']]
    assert check_for_winner(board) == 'X'

    board = [['X', ' ', 'O'],
             ['O', 'O', 'X'],
             ['X', ' ', 'X']]
    assert check_for_winner(board) == 'X'

