import pytest
from tic_tac_toe import make_board, get_player_move

def test_get_player_move(monkeypatch, capsys):
    # Create an empty board
    board = make_board()
    player_team = 'X'

    # Simulate inputs in the following order [0,0], [1,1], [1,1]
    inputs = iter(['0','0','1','1','1','1','2','2'])
    monkeypatch.setattr('builtins.input', lambda _: next(inputs))

    # Check if the board is updated correctly with board[0][0] = 'X'
    get_player_move(board, player_team)
    assert board == [['X', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]

    # Check if the board is updated correctly with board[1][1] = 'X'
    get_player_move(board, player_team)
    assert board == [['X', ' ', ' '], [' ', 'X', ' '], [' ', ' ', ' ']]

    # Check if 'Space Occupied!' is printed if the input is ['1', '1'] again
    player_team = 'X'  # Let's try to place X again at the same position
    get_player_move(board, player_team)
    captured = capsys.readouterr()
    assert 'Space Occupied!' in captured.out
    assert board == [['X', ' ', ' '], [' ', 'X', ' '], [' ', ' ', 'X']]

if __name__ == "__main__":
    pytest.main()
