import pytest
from tic_tac_toe import make_board

def test_make_board():
    board = make_board()
    assert len(board) == 3  # Check if the board has 3 rows
    for row in board:
        assert len(row) == 3  # Check if each row has 3 elements
        for cell in row:
            assert cell == ' '  # Check if each cell is initialized as an empty string

if __name__ == "__main__":
    pytest.main()
