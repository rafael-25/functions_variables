def half(bill, tax, tip):
    """
    Suppose you are eating out at a restaurant with a friend and want to split the bill
    evenly.

    Calculate the cost to be paid by two patrons evenly splitting the bill at a restaurant.

    Inputs:
        bill (float or int): The bill amount before tax and tip are applied.
        tax (float or int):  The tax amount to be added to the bill.
        tip (float or int):  The tip amount to be added to the bill after tax.

    Returns:
        float: The cost to be paid by each patron after splitting the bill evenly.

    Note: You will need to express tax and tip as percentages.
    """