# Markup Challenge

## Task

Use HTML tags to structure (mark-up) the information about the Rubik cube.

- To view how your page is rendered, use `http-server` in the terminal.

- Refer to `solution.png` to compare your rendered page to what the page should look like.

![Solution](solution.png)
