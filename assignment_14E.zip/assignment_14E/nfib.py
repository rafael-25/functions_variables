import math

def nth_fibonacci_number(n):
    """
    Fibonacci numbers are 1, 1, 2, 3, 5, 8, 13, 21, 34,... The first two Fibonacci
    numbers are both 1. Each Fibonacci number after that is the sum of the two previous
    Fibonacci numbers.

    Calculate the nth Fibonacci number using Binet's Formula. The formula is
    described in detail here:

    Inputs:
        n (int): A non-negative integer representing the position of the desired Fibonacci
                 number.

    Returns:
        int: The nth Fibonacci number.

    The Fibonacci sequence starts with 0 as the 0th number and 1 as the 1st number.
    This function returns the nth Fibonacci number in the sequence, where n is a
    non-negative integer.
    """
