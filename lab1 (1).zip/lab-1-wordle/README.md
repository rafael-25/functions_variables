# Lab Assignment: Wordle Clone
## Learning Objectives and Standards

## Overview

**Wordle** is a game popularized by the New York Times where you have six chances to guess a five-letter word. The online version of this game incorporates color hints to guide players toward the correct word by indicating which letters are correct, misplaced, or not in the word.

In this lab, you will implement a text-based version of the game, focusing on coding logic to check guesses, provide feedback, and determine the outcome of the game. This lab reinforces skills in string manipulation, loops, and conditionals.

```bash
Welcome to the Wordle Clone!
Can you solve the word of the day?

Enter a 5-letter word: crane
CRANE | ⬜🟩⬜⬜⬜
5 guesses left.

Enter a 5-letter word: plate
PLATE | ⬜⬜⬜⬜⬜
4 guesses left.

Enter a 5-letter word: grave
GRAVE | 🟩🟩⬜⬜⬜
3 guesses left.

Enter a 5-letter word: grain
GRAIN | 🟩🟩⬜🟨🟨
2 guesses left.

Enter a 5-letter word: grind
GRIND | 🟩🟩🟩🟩🟩
Congrats! You've solved today's challenge!
```

**Note:** This lab uses the real wordle list. Therefore, your program will behave differently every time.

## Task 1: `get_player_guess()`

### Description
Write a function that prompts the player for a valid 5-letter word and re-requests input until the guess meets all validation requirements.

### Details
- **Input**: None (this function interacts with the player through `input()`).
- **Output**: A valid 5-letter word as a string.
- **Logic**:
  1. Prompt the player with: `"Enter a 5-letter word: "`.
  2. Ensure the word meets the following criteria:
     - **Exactly 5 characters long**.
     - **Contains only letters** (no numbers or special characters).
     - **Exists in the wordlist** (use the provided `check_valid_word()` function).
  3. If the guess is invalid, display an error message and re-prompt the player.
  4. If the guess is valid, return it.

<details>
<summary><b>Helpful Details If You Are Stuck</b></summary>

1. **Prompt for Input**:
   - Use `input()` to ask the user to enter a word.
   - Remove any extra spaces and make the input lowercase with `.strip()` and `.lower()`.

2. **Check the Word Length**:
   - Verify that the input is exactly 5 characters long.
   - If not, display: `"Invalid word! Your guess must be exactly 5 letters."`

3. **Check for Alphabetic Characters**:
   - Ensure the word contains only letters using `.isalpha()`.
   - If not, display: `"Invalid word! Your guess must contain only letters."`

4. **Check the Wordlist**:
   - Use the `check_valid_word()` function to confirm the word is in the wordlist.
   - If not, display: `"Invalid word! That word is not in the wordlist."`

5. **Repeat Until Valid**:
   - Use a `while` loop to re-prompt until the input passes all validation checks.

6. **Return the Word**:
   - Once a valid word is entered, return it.

</details>

## Example
```bash
Enter a 5-letter word: cr4ne
Invalid word! Your guess must contain only letters.

Enter a 5-letter word: cranee
Invalid word! Your guess must be exactly 5 letters.

Enter a 5-letter word: abcde
Invalid word! That word is not in the wordlist.

Enter a 5-letter word: crane
CRANE | ⬜🟩⬜⬜⬜
5 guesses left.

Enter a 5-letter word:
```

## Task 2: `has_won(secret, guess)`

### Description
Write a function that checks if the player's guess matches the secret word. If the guess matches, this function will signal to the main game loop that the game is over.

### Details
- **Input**:
  - `secret` (str): The secret word to be guessed.
  - `guess` (str): The word entered by the player.
- **Output**:
  - A boolean value (`True` or `False`).
    - `True`: If the guess matches the secret word.
    - `False`: Otherwise.
- **Logic**:
  - Compare the `secret` word with the `guess` word.
  - If they are equal, return `True`.
  - If they are not equal, return `False`.

<details>
<summary><b>Helpful Details If You Are Stuck</b></summary>

- Compare the `secret` and `guess` using the `==` operator.
- Return `True` if they are the same.
- Return `False` otherwise.

</details>

## Example

```bash
secret = "crane"
guess = "crane"
has_won(secret, guess)  # Output: True

secret = "crane"
guess = "plane"
has_won(secret, guess)  # Output: False
```
## Task 3: `get_feedback(guess)`

### Description
Write a function that generates feedback for the player's guess based on its similarity to the secret word. Feedback should use the following symbols:
- 🟩: Correct letter in the correct position.
- 🟨: Correct letter in the wrong position.
- ⬜: Letter not in the secret word.

### Details
- **Input**:
  - `secret` (str): The secret word to be guessed.
  - `guess` (str): The word entered by the player.
- **Output**:
  - A string of emoji symbols (`🟩`, `🟨`, `⬜`) representing the feedback for the guess.
- **Logic**:
  1. Loop through the characters in `guess`.
  2. For each character:
     - Add 🟩 if the letter matches the corresponding position in `secret`.
     - Add 🟨 if the letter exists in `secret` but is in the wrong position.
     - Add ⬜ if the letter does not exist in `secret`.

<details>
<summary><b>Helpful Details If You Are Stuck</b></summary>

- **Loop Through `guess`**:
  - Use a `for` loop to iterate over each character in the guess.
  - Use string indexing (`secret[i]`) to compare characters.
   - The in keyword can check if a character exists anywhere in secret.

- **Check Each Character**:
  - Use an `if`-`elif`-`else` structure:
    - **If** the character matches the character in the same position in `secret`, add 🟩 to the feedback string.
    - **Elif** the character exists in `secret` but is in a different position, add 🟨.
    - **Else**, add ⬜ to indicate the character is not in `secret`.

- **Build the Feedback String**:
  - Create a variable that is an empty string (`feedback = ""`)
  - Concatenate the emoji results to form the feedback string.
  - Use the addition operator (`+`) to concatenate strings

- **Return the Feedback**:
  - Return the completed feedback string after the loop.

</details>

## Example
```python
# Example 1
secret = "crane"
guess = "crane"
give_feedback(secret, guess)  # Output: "🟩🟩🟩🟩🟩"

# Example 2
secret = "crane"
guess = "crate"
give_feedback(secret, guess)  # Output: "🟩🟩🟩⬜🟩"

# Example 3
secret = "crane"
guess = "cakes"
give_feedback(secret, guess)  # Output: "🟩🟨⬜🟨⬜"
```
## Task 4: `display_game_state(guess, feedback)`

### Description
Write a function that displays the current game state by formatting the player's guess and its corresponding feedback. The output should be in the format:

- `<GUESS> | <FEEDBACK>`

## Details
- **Input**:
  - `guess` (str): The guessed word entered by the player.
  - `feedback` (str): The emoji feedback string corresponding to the guess.
- **Output**:
  - None. The function should print the formatted string.
- **Logic**:
  - Combine the `guess` and `feedback` in the specified format.
  - Use `print()` to display the result.

<details>
<summary><b>Helpful Details If You Are Stuck</b></summary>

1. **Capitalize the Guess**:
   - Use the `.upper()` method to display the guess in uppercase.

2. **Format the Output**:
   - Concatenate the `guess` and `feedback` strings using the `" | "` separator.

   Example:
   ```python
   formatted_output = f"{guess.upper()} | {feedback}"

2. **Print the Output:**:
   - Use `print()` to display the formatted string.
</details>

## Example
```python
# Example 1
guess = "crane"
feedback = "🟩🟩🟩🟩🟩"

display_game_state(guess, feedback)
CRANE | 🟩🟩🟩🟩🟩 # Printed Output

# Example 2
guess = "crate"
feedback = "🟩🟩🟩⬜🟩"

display_game_state(guess, feedback)
CRATE | 🟩🟩🟩⬜🟩 # Printed Output
```

## Task 5: Main Game Loop

### Description
Write a function that serves as the main game loop for the Wordle Clone. This function will manage the entire game flow:
- Players guess the secret word within a limited number of attempts.
- Feedback is generated for each guess.
- The game ends when the player guesses the word correctly or runs out of attempts.

### Details
- **Input**:
  - `secret` (str): The secret word to be guessed.
- **Output**:
  - None. This function should manage the game flow, including displaying win/lose messages.
- **Logic**:
  1. Display a welcome message.
  2. Allow up to 6 guesses.
  3. For each guess:
     - Validate and get the player's guess (`get_player_guess`).
     - Generate feedback for the guess (`give_feedback`).
     - Display the game state (`display_game_state`).
     - Check if the player has won (`has_won`).
  4. End the game:
     - Display a success message if the player wins.
     - Reveal the secret word if the player runs out of attempts.

<details>
<summary><b>Helpful Details If You Are Stuck</b></summary>

1. **Validate and Get the Player's Guess**:
   - Call the `get_player_guess()` function to retrieve a valid guess.

2. **Generate Feedback**:
   - Call `give_feedback(secret, guess)` to create feedback for the guess.

3. **Display the Game State**:
   - Call `display_game_state(guess, feedback)` to show the current guess and feedback.

4. **Check if the Player has Won**:
   - Use `has_won(secret, guess)` to determine if the game is over.
   - If the function returns `True`:
     - Display a success message:
       ```
       Congrats! You've solved today's challenge!
       ```
     - Display
     - Break out of the loop.

5. **Increment Attempts**:
   - Add 1 to `attempts` at the end of each loop iteration.

6. **Handle Losing/Winning the Game**:
   - If the player runs out of attempts, display a message revealing the secret word:
     ```
     Game Over! The word was: <SECRET_WORD>
     ```
</details>

### Winning Example
```plaintext
Welcome to the Wordle Clone!
Can you solve the word of the day?

Enter a valid 5-letter word: crane
CRANE | ⬜🟩🟨⬜⬜
5 guesses left.

Enter a valid 5-letter word: trian
Invalid word! That word is not in the wordlist.

Enter a valid 5-letter word: train
TRAIN | 🟩🟩🟨🟨⬜
4 guesses left.

Enter a valid 5-letter word: triad
TRIAD | 🟩🟩🟩🟩🟩
Congrats! You've solved today's challenge!
```

### Losing Example
```plaintext
Welcome to the Wordle Clone!
Can you solve the word of the day?

Enter a valid 5-letter word: crane
CRANE | ⬜🟩🟨⬜⬜
5 guesses left.

Enter a valid 5-letter word: trian
Invalid word! That word is not in the wordlist.

Enter a valid 5-letter word: train
TRAIN | 🟩🟩🟨🟨⬜
4 guesses left.

Enter a valid 5-letter word: triad
TRIAD | 🟩🟩🟩🟩🟩
Congrats! You've solved today's challenge!
```

## Testing Your Functions (Tasks 1-4)

**Note**: You must test your main function manually. Your game should be fully functional.

### Step 1: Install pytest
To install pytest, run the following command in your terminal:
```bash
$ pip install pytest
```

### Step 2: Reviewing Test Results

pytest will display a summary of the results:

- A green dot (.) indicates a test passed.
- A red F indicates a test failed, with details about the error provided.

```bash
================= test session starts ==================
collected 8 items

test_wordle.py ........                        [100%]

================= 8 passed in 0.11s ====================
```

Debugging Failed Tests

If any tests fail:

- Review the function's implementation based on the error message.

- Make the necessary corrections in your code.

- Rerun pytest until all tests pass.

---

## Acknowledgment

This assignment was adapted from Nifty Assignments. I take no credit for its creation and have only adapted it for instructional purposes.
