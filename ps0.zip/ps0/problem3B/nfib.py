import math
def nth_fibonacci_number(n):
    """
    The Fibonacci numbers are 1, 1, 2, 3, 5, 8, 13, 21, 34,... The first two Fibonacci
    numbers are both 1. Each Fibonacci number after that is the sum of the two previous
    Fibonacci numbers.

    Write the implementation of this function, nth_fibonacci_number(n), which takes a
    non-negative (int) n and returns the nth Fibonacci number.

    You may use Binet's Fibonacci Number Formula, which uses the golden
    ratio to compute this result. Keep in mind that this formula starts counting
    at n = 1, and we start counting at n = 0, so you may have to make some
    adjustments to the formula.
    """
    