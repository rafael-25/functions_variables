# DO NOT CHANGE THE CONTENTS OF THIS FILE
import pytest
from nfib import nth_fibonacci_number

def test_1st():
    assert nth_fibonacci_number(1) == 1

def test_2nd():
    assert nth_fibonacci_number(2) == 1

def test_5th():
    assert nth_fibonacci_number(5) == 5

def test_9th():
    assert nth_fibonacci_number(9) == 34

def test_12th():
    assert nth_fibonacci_number(12) == 144
