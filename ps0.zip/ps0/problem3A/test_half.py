# DO NOT CHANGE THE CONTENTS OF THIS FILE
import pytest
from half import half

def test_half1():
    assert half(12.50,8.875,20) == "$8.17"

def test_half2():
    assert half(23.50,7,15) == "$14.46"

def test_half3():
    assert half(100,6.25,18) == "$62.69"
