def half(bill, tax, tip):
    """
    Suppose you are eating out at a restaurant with a friend and want to split the bill
    evenly.

    Write the implementation of the function half which computes the price to pay for two
    patrons who intend to split the bill. The function accepts three parameters, bill, tax
    and tip, all of which can be type float or int.
    """