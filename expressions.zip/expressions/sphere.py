"""
Create an interactive program that:

    (1) Prompts the user for a sphere's diameter.

    (2) Calculates and displays its volume and surface area,
        rounded to two decimal places.

Sample program run:

    What is the diameter of the sphere: 10
    The volume is 523.6
    The surface area is 314.16
"""
