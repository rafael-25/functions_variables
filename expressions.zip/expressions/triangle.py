"""
Create an interactive program that:

    (1) Asks the user for the lengths of the side of a triangle (a, b and c)

    (2) Uses Heron's formula to calculate and displays its area,
        rounded to two decimal points.

Sample program run:

    What is the length of side a: 10
    What is the length of side b: 11.7
    What is the length of side c: 7
    The area is 34.87
"""
