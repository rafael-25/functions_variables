"""
Create an interactive program that computes the compound interest of a principal
deposit over a specified number of years, applying interest on a monthly basis,
and allowing the user to set the interest rate.

The program should:

    (1) Calculate the compound interest, rounded to two decimal places.

    (2) Apply the interest on a monthly basis.

    (3) Allow the user to input and set the annual interest rate.

The annual interest rate should be calculated using the formula:

    annual_interest = principal * (1 + interest_rate / 12) ^ (12 * years)

Sample program run:

    What is the principal: 10000
    What is the interest rate: 2.85
    How many years: 7.5
    Your total balance after 90 months is $12,379.99
"""