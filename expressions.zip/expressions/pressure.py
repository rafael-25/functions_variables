"""
Create an interactive program that:

    (1) Calculates water pressure for a given depth and displays it,
        rounded to one decimal point.

The formula for water pressure (in Pascals) is:

    pressure = density * gravitational_acceleration * depth

You can assume the density of the water is measured as 1000 (kg/m^3) and that
gravitaional_acceleration is 9.8 (m/s^2).

Sample program run:

    Enter the depth (meters): 10
    The water pressure is 98000.0 Pascals.
"""