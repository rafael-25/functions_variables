import pytest


def distance(x1, y1, x2, y2):
    """
    Calculate the distance between two points in a two-dimensional plane.

    You may want to conduct a google search of what the distance formula is, then implement
    that within this function. You will need the math module to complete this problem.

    Inputs:
        x1 (int or float): X-coordinate of the first point.
        y1 (int or float): Y-coordinate of the first point.
        x2 (int or float): X-coordinate of the second point.
        y2 (int or float): Y-coordinate of the second point.

    Returns:
        float: The distance between the two points, rounded to two decimal places.
    """


# NOTE: DO NOT MODIFY ANYTHING BEYOND THIS POINT
# To test your function, execute the following command in your terminal: pytest distance.py
def test_ints():
    assert distance(0, 0, 3, 4) == 5.0
    assert distance(-1, -1, 2, 3) == 5.0
    assert distance(1, 2, 1, 2) == 0.0
    assert distance(10, 5, 8, 2) == 3.61
    assert distance(-1, -1, -4, -4) == 4.24
