import pytest

def how_many_pizzas(students, slices_per_student):
    """
    A group of students wants to buy some pizza. Assume that each student will have the same
    number of slices. Also, assume that all pizzas have 8 slices, and they cannot be
    purchased by slice, so buying one slice of pizza requires buying the whole pizza.

    Calculate the number of pizzas needed to feed a group of students based on
    their slice consumption.

    Inputs:
        students (int): The number of students (a non-negative integer).

        slices_per_student (int): The number of slices each student will eat
                                  (a non-negative integer).

    Returns:
        int: The integer number of pizzas required to feed all the students.
    """


def left_over_slices(students, slices_per_student):
    """
    As with the previous function, all pizzas have 8 slices, and you can only purchase whole
    pizzas. This means that there may be a few leftover slices.

    Calculate how many slices of pizza each student will eat, and return the
    number of pizza slices that will be leftover.

    Args:
        students (int): The number of students (a non-negative integer).

        slices_per_student (int): The number of slices each student will eat (a non-negative integer).

    Returns:
        int: The number of pizza slices that will be leftover.
    """



# NOTE: DO NOT MODIFY ANYTHING BEYOND THIS POINT
# To test your function, execute the following command in your terminal: pytest pizza.py
def test_how_many_pizzas():
    assert how_many_pizzas(16, 2) == 2
    assert how_many_pizzas(25, 3) == 10
    assert how_many_pizzas(5, 8) == 5
    assert how_many_pizzas(10, 1) == 2

def test_left_over_slices():
    assert left_over_slices(16, 2) == 0
    assert left_over_slices(25, 3) == 7
    assert left_over_slices(5, 8) == 0
    assert left_over_slices(10, 1) == 6
