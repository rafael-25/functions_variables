// Function to change page color based on checkbox
function changePageColor(box) {
  // If checkbox is checked
  if (box.checked) {
    // Get color value from input field
    let boxContent = document.getElementById('pageColor').value;
    // If color value is empty, set background to powder blue and text to black
    if (boxContent == "") {
      document.body.style.background = 'powderblue';
      document.body.style.color = 'black';
    } else {
      // Otherwise, set background to the specified color
      document.body.style.background = boxContent;
    }
  } else {
    // If checkbox is unchecked, set background to crimson and text to white
    document.body.style.background = 'crimson';
    document.body.style.color = 'white';
  }
}

// Function to set initials
function setInitials() {
  // Get first and last name values
  let firstName = document.getElementById("fname").value;
  let lastName = document.getElementById("lname").value;
  // Set initials in a specific format
  document.getElementById("initials").innerHTML = firstName.substring(0, 1) + ". " + lastName.substring(0, 1) + ".";
}

// Function to respond to a device selection
function respond(device) {
  // Set response message based on selected device
  document.getElementById("runner").innerHTML = device.value + " is an excellent runner.";
}

// Function to evaluate time and provide feedback
function evaluateTime(rad) {
  // Get element for displaying feedback
  let timesElement = document.getElementById("times");
  // Set feedback based on selected time range
  if (rad.value == "9") {
    timesElement.innerHTML = "Keep practicing.";
  } else if (rad.value == "8") {
    timesElement.innerHTML = "Try for 7:59.";
  } else if (rad.value == "7") {
    timesElement.innerHTML = "Try for 6:59.";
  } else if (rad.value == "6") {
    timesElement.innerHTML = "Very respectable.";
  } else if (rad.value == "5") {
    timesElement.innerHTML = "You are a competitor.";
  } else if (rad.value == "4") {
    timesElement.innerHTML = "One of the very best.";
  } else if (rad.value == "3") {
    timesElement.innerHTML = "Record Setter!!!";
  }
}

// Function to print a string to an output element
function print(str) {
  document.getElementById("output").innerHTML += str + "<br />";
}

// Function to examine likes and provide feedback
let boxes = []; // This is a list.
function examineLikes() {
  // If boxes list is empty, populate it with checkbox elements
  if (boxes.length == 0) {
    boxes.push(document.getElementById("box1"));
    boxes.push(document.getElementById("box2"));
    boxes.push(document.getElementById("box3"));
    boxes.push(document.getElementById("box4"));
  }

  // Get output element for displaying feedback
  let outputElement = document.getElementById("output");
  outputElement.innerHTML = "";
  let count = 0;

  // Count checked checkboxes
  for (var rep = 0; rep < boxes.length; rep++) {
    if (boxes[rep].checked) {
      count++;
    }
  }

  // Provide feedback based on the number of checked checkboxes
  if (count == 0) {
    outputElement.innerHTML = "You have no interest in running.";
  } else if (count <= 2) {
    outputElement.innerHTML = "Thank you for revealing your running interest.";
  }
  else if (count > 2) {
    outputElement.innerHTML = "Wow! You must really love to run!";
  }
}

// Function to change all images to a specific picture
function changePics() {
    // Set the picture URL
    let pic = "https://media2.giphy.com/media/DM9e4BDcNpIzJFWBWV/giphy.gif";
    // Change src attribute of all images to the specified picture URL
    for (var rep = 0; rep < document.images.length; rep++) {
        document.images[rep].src = pic;
    }
}
