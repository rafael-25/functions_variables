import pytest


def get_green(color):
    """
    Extract and return the green component from an RGB color represented as a single integer.

    Colors are represented as RGB values, where each of the red, green, and blue components
    are between 0 and 255 (inclusive). The RGB value is represented as a single integer,
    with the leftmost three digits denoting red, the next three digits denoting green, and
    the last three digits denoting blue. Leading zeros are allowed.

    For example, the RGB values for orchid are 218 (red), 112 (green), and 214 (blue), which
    are represented as the single integer 218112214.

    Inputs:
        color (int): An RGB color represented as a single integer.

    Returns:
        int: The integer value of the green component of the given color.

    Example:
        get_green(218112214) returns 112.
    """


# NOTE: DO NOT MODIFY ANYTHING BEYOND THIS POINT
# To test your function, execute the following command in your terminal: pytest green.py
def test_green():
    assert get_green(218112214) == 112
    assert get_green(100032175) == 32
    assert get_green(255000000) == 0
    assert get_green(255255255) == 255
    assert get_green(128064032) == 64
    assert get_green(101001001) == 1
