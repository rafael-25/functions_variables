def count_infected(city):
    """
    Count the number of infected people in the city.

    :param city (list): List of strings representing the city's state.

    :returns int: The number of infected people.
    """
    pass


def has_infected_neighbor(city, position):
    """
    Check if a susceptible person at the given position has an infected neighbor.

    :param city (list): List of strings representing the city's state.
    :param position (int): Position of the person in the city.
    :returns bool: True if the person has an infected neighbor, False otherwise.
    """
    pass


def advance_person(city, position, days_contagious):
    """
    Advance the state of a person in the city.

    :param city (list): List of strings representing the city's state.
    :param position (int): Position of the person in the city.
    :param days_contagious (int): Number of days a person remains contagious.
    :returns str: The new state of the person.
    """
    pass


def simulate_one_day(city, days_contagious):
    """
    Simulate the spread of the disease for one day.

    :param city (list): List of strings representing the city's state.
    :param days_contagious (int): Number of days a person remains contagious.
    :returns list: Updated city state after one day.
    """
    pass


def run_simulation(city, days_contagious):
    """
    Run the simulation until there are no infected people.

    :param city (list): Initial state of the city.
    :param days_contagious (int): Number of days a person remains contagious.
    :returns tuple: Final state of the city and number of days simulated.
    """
    pass


if __name__ == "__main__":
    # Example: Simulate a city with 3 people contagious for 2 days
    city = ["S", "I0", "S"]
    days_contagious = 2
    final_state, days = run_simulation(city, days_contagious)
    print(f"Final state: {final_state}")
    print(f"Days simulated: {days}")
