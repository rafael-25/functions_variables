from epidemics import count_infected, has_infected_neighbor, advance_person, simulate_one_day, run_simulation
import pytest

def test_count_infected():
    assert count_infected(["I0", "I1", "S", "R"]) == 2
    assert count_infected(["S", "S", "S", "R"]) == 0
    assert count_infected(["I0", "I0", "I0"]) == 3
    assert count_infected([]) == 0
    assert count_infected(["R", "R", "R"]) == 0
    assert count_infected(["S", "S", "S", "I0", "R", "I1", "R"]) == 2
    assert count_infected(["I0"] * 20 + ["S"] * 10 + ["R"] * 5) == 20

def test_has_infected_neighbor():
    assert has_infected_neighbor(["I0", "S", "S"], 1) is True
    assert has_infected_neighbor(["S", "S", "S"], 0) is False
    assert has_infected_neighbor(["S", "I0", "S"], 0) is True
    assert has_infected_neighbor(["S", "S", "I0"], 1) is True
    assert has_infected_neighbor(["I1", "S", "I0"], 1) is True
    assert has_infected_neighbor(["S"], 0) is False
    assert has_infected_neighbor(["S", "I0"], 1) is False
    assert has_infected_neighbor(["I0", "R", "S", "I1"], 2) is True

def test_advance_person():
    assert advance_person(["I0", "S", "S"], 0, 2) == "I1"
    assert advance_person(["I1", "S", "S"], 0, 2) == "R"
    assert advance_person(["S", "I0", "S"], 0, 2) == "I0"
    assert advance_person(["S", "S", "S"], 0, 2) == "S"
    assert advance_person(["R", "S", "I0"], 0, 2) == "R"
    assert advance_person(["S", "I1", "S", "R"], 1, 3) == "I0"
    assert advance_person(["I2", "R", "S", "I0"], 0, 3) == "R"

def test_simulate_one_day():
    assert simulate_one_day(["S", "I0", "S"], 2) == ["I0", "I1", "I0"]
    assert simulate_one_day(["R", "I1", "S"], 2) == ["R", "R", "I0"]
    assert simulate_one_day(["I2", "I1", "I0"], 2) == ["R", "R", "I1"]
    assert simulate_one_day(["S", "S", "S"], 2) == ["S", "S", "S"]
    assert simulate_one_day(["R", "R", "R"], 2) == ["R", "R", "R"]
    assert simulate_one_day(["S", "S", "I0", "S", "I1"], 3) == ["S", "I0", "I1", "I0", "R"]
    assert simulate_one_day(["I0", "S", "S", "R", "S", "I1"], 3) == ["I1", "I0", "S", "R", "I0", "R"]

def test_run_simulation():
    assert run_simulation(["S", "I0", "S"], 2) == (["R", "R", "R"], 3)
    assert run_simulation(["S", "R", "I0"], 2) == (["S", "R", "R"], 2)
    assert run_simulation(["S", "S", "S"], 2) == (["S", "S", "S"], 0)
    assert run_simulation(["R", "R", "R"], 2) == (["R", "R", "R"], 0)
    assert run_simulation(["I0", "I0", "I0"], 2) == (["R", "R", "R"], 3)
    assert run_simulation(["S", "I0", "S", "S", "I1", "R"], 3) == (["R", "R", "R", "R", "R", "R"], 4)
    assert run_simulation(["S", "S", "I0", "R", "I1", "S"], 4) == (["R", "R", "R", "R", "R", "R"], 6)
    assert run_simulation(["I0"] * 10 + ["S"] * 10, 3) == (["R"] * 20, 12)
    assert run_simulation(["S"] * 10 + ["I0"] + ["R"] * 10, 1) == (["S"] * 10 + ["R"] * 11, 1)
