# Epidemics Lab: Modeling Disease Spread

## Overview

In this lab, you will simulate the spread of a disease within a small community using a simplified version of the **SIR Model** (Susceptible, Infected, Recovered). This model is widely used in epidemiology to understand how infectious diseases spread over time and to help predict and mitigate their impact.

### What is the SIR Model?

The **SIR Model** divides a population into three compartments:

1. **Susceptible (S):** Individuals who are not yet infected but can contract the disease.
2. **Infected (I):** Individuals who are currently infected and can spread the disease.
3. **Recovered (R):** Individuals who have recovered from the disease and are no longer susceptible.

The model uses a set of mathematical equations to describe the transitions between these states. The spread of a disease depends on factors such as the rate of infection, recovery, and interactions within the community.

### Why is the SIR Model Useful?

The SIR Model provides a simplified yet powerful way to study and predict disease dynamics. By analyzing the spread, public health officials and researchers can:

- Identify critical points to implement interventions.
- Predict the peak of infections and overall duration of outbreaks.
- Assess the impact of measures like social distancing, vaccination, or quarantine.

### Real-World Example: COVID-19

The SIR Model gained prominence during the COVID-19 pandemic as it helped scientists and policymakers understand the spread of the virus. For example, the model was used to:

- Estimate the basic reproduction number (R₀), indicating how contagious the virus was.
- Simulate scenarios with and without interventions like lockdowns and mask mandates.
- Plan for resource allocation in hospitals by predicting infection peaks.

### Lab Goals

In this lab, you will:
- Write a series of functions to simulate disease spread through a city.
- Use the principles of the SIR Model to track changes in the **Susceptible**, **Infected**, and **Recovered** populations over time.
- Develop efficient and interconnected functions to model these transitions effectively.

By the end of this lab, you will gain a deeper understanding of how mathematical modeling can be applied to real-world problems and how computational simulations can aid in decision-making during health crises.

---

## Objectives
- Practice **conditionals**, **loops**, and **functions** in Python.
- Understand how to represent and manipulate data using lists.
- Explore real-world applications of programming in disease modeling.

---

## Rules of the Simulation

1. **States**:
   - `S`: Susceptible (healthy but can get infected).
   - `I0`, `I1`, `I2`: Infected states (`I0` means just infected, `I1` means infected for 1 day, etc.).
   - `R`: Recovered (immune to infection).

2. **City Representation**:
   - The city is a list of strings, where each string represents a person's disease state (e.g., `['S', 'I1', 'S', 'R']`).

3. **Infection Rules**:
   - A susceptible (`S`) person becomes infected (`I0`) if they have an infected neighbor (`I0`, `I1`, etc.).
   - Infected people progress daily (`I0` → `I1`, `I1` → `I2`).
   - After `days_contagious` days, an infected person recovers (`I2` → `R`).
   - Once recovered, that individual is immune and can not be reinfected.

4. **Stopping Condition**:
   - The simulation ends when no one is infected (`I0`, `I1`, etc.).

---
## Tasks

You will need to implement five core functions (Tasks 1 to 5), each handling a specific aspect of simulation.

- **Task 1:** Correctly counts all infected people in a city.
- **Task 2:** Identifies infected neighbors accurately.
- **Task 3:** Updates the state of a person in the city.
- **Task 4:** Simulates a single day within the city.
- **Task 5:** Runs the simulation until all persons are uninfected.

---

### Task 1: `count_infected(city)`

#### Description
Write a function that counts the total number of infected individuals (`I0`, `I1`, etc.) in the city.

#### Details
- **Input**: A list `city` containing strings representing disease states (e.g., `['S', 'I1', 'R']`).
- **Output**: An integer representing the number of infected people in the city.
- **Logic**:
  - Loop through the list and count all individuals whose state starts with `'I'`.
- **Example**:
  ```python
  count_infected(['S', 'I0', 'I1', 'R'])  # Output: 2
  count_infected(['S', 'S', 'S'])         # Output: 0
    ```
### Task 2: `has_infected_neighbor(city, position)`

#### Description
Write a function to determine if a person at a specific position in the city has at least one infected neighbor.

#### Details
- **Input**:
  - `city`: A list of strings representing disease states.
  - `position`: The index of the person in the city.
- **Output**: A boolean value (`True` or `False`) indicating whether the person has an infected neighbor.
- **Logic**:
  - If the person is the first in the list, check only their right neighbor.
  - If the person is the last in the list, check only their left neighbor.
  - For everyone else, check both left and right neighbors.
- **Example**:
  ```python
  has_infected_neighbor(['S', 'I0', 'S'], 0)  # Output: True
  has_infected_neighbor(['S', 'R', 'S'], 1)  # Output: False
  ```

### Task 3: `advance_person(city, position, days_contagious)`

#### Description
Write a function to advance the state of a person in the city by one day.

#### Details
- **Input**:
  - `city`: A list of strings representing disease states.
  - `position`: The index of the person in the city.
  - `days_contagious`: The number of days a person remains contagious.
- **Output**: A string representing the new state of the person.
- **Logic**:
  1. If the person is `S` and has an infected neighbor, change their state to `I0`.
  2. If the person is infected (`I0`, `I1`, etc.), increment their infection state (`I0` → `I1`).
  3. If the infection duration exceeds `days_contagious`, change their state to `R`.
  4. If the person is already `R`, their state does not change.

#### Example
```python
advance_person(['S', 'I0', 'S'], 0, 2)  # Output: 'I0'
advance_person(['I1', 'S', 'R'], 0, 2)  # Output: 'I2'
advance_person(['R', 'S', 'S'], 2, 2)   # Output: 'R'
```

### Task 4: `simulate_one_day(city, days_contagious)`

#### Description
Write a function to simulate a single day of the epidemic.

#### Details
- **Input**:
  - `city`: A list of strings representing the disease states of all individuals.
  - `days_contagious`: The number of days a person remains contagious.
- **Output**: A new list representing the updated states of all individuals after one day.
- **Logic**:
  1. Iterate through the city.
  2. Update each person's state using the `advance_person` function.

#### Example
```python
simulate_one_day(['S', 'I0', 'S'], 2)  # Output: ['I0', 'I1', 'I0']
simulate_one_day(['R', 'I1', 'S'], 2)  # Output: ['R', 'R', 'I0']
```

### Task 5: `run_simulation(city, days_contagious)`

#### Description
Write a function to run the simulation until there are no infected people left in the city.

#### Details
- **Input**:
  - `city`: A list of strings representing the initial state of all individuals.
  - `days_contagious`: The number of days a person remains contagious.
- **Output**: A tuple containing:
  1. The final state of the city (a list).
  2. The number of days the simulation ran.
- **Logic**:
  1. Use the `simulate_one_day` function in a loop until the stopping condition is met (i.e., no infected individuals left in the city).
  2. Count the number of days the simulation runs.

#### Example
```python
run_simulation(['S', 'I0', 'S'], 2)  # Output: (['R', 'R', 'R'], 3)
run_simulation(['S', 'R', 'I0'], 2)  # Output: (['S', 'R', 'R'], 2)
```

---

## Helpful Resources

Here are helpful resources from W3Schools that align with the tasks in the lab.

---

### General Python Basics
- [Python Introduction](https://www.w3schools.com/python/python_intro.asp)

### 1. Conditionals (if, elif, else)
- [Python If...Else](https://www.w3schools.com/python/python_conditions.asp)
- **Relevant Tasks**: Task 2, Task 3

### 2. For Loops
- [Python For Loops](https://www.w3schools.com/python/python_for_loops.asp)
- **Relevant Tasks**: Task 4, Task 5

### 3. Lists
- [Python Lists](https://www.w3schools.com/python/python_lists.asp)
- **Relevant Tasks**: Task 1, Task 2, Task 3, Task 4, Task 5

### 4. Functions
- [Python Functions](https://www.w3schools.com/python/python_functions.asp)
- **Relevant Tasks**: All tasks

## Acknowledgment

This assignment was originally developed for CS 121 at UChicago by its professors. I take no credit for its creation and have only adapted it for instructional purposes.
