# Grading Rubric

## Task 1: `count_infected` (5 points)
- Correctly counts all infected states in the city (5 pts).

## Task 2: `has_infected_neighbor` (5 points)
- Handles edge cases (first/last person) correctly (3 pts).
- Identifies infected neighbors accurately (2 pts).

## Task 3: `advance_person` (10 points)
- Correctly advances susceptible and infected states (7 pts).
- Handles recovered state (3 pts).

## Task 4: `simulate_one_day` (10 points)
- Updates all individuals correctly using `advance_person` (6 pts).
- Returns a new city list with correct states (4 pts).

## Task 5: `run_simulation` (10 points)
- Runs until stopping condition is met (5 pts).
- Returns final state and days simulated (5 pts).

---

## Additional Points
- Code readability and comments (5 pts).
- Passing all test cases (5 pts).

### Total: 50 points
