# Grading Rubric

## Task 1: `count_infected` (8 points)
- Correctly counts all infected states (`I0`, `I1`, etc.) in the city (8 pts).
  - Partial credit (4 pts): Attempts logic but misses edge cases or incorrect counting.

---

## Task 2: `has_infected_neighbor` (10 points)
- Handles edge cases (first and last person) correctly (6 pts).
- Identifies infected neighbors accurately for all positions (4 pts).
  - Partial credit (2 pts): Correctly identifies neighbors for some positions but not others.

---

## Task 3: `advance_person` (15 points)
- Correctly advances susceptible (`S`) to infected (`I0`) states when appropriate (5 pts).
- Advances infected states (`I0` → `I1` → etc.) correctly based on `days_contagious` (6 pts).
- Handles recovery state (`R`) correctly (4 pts).
  - Partial credit (3 pts): Handles some transitions but not all edge cases.

---

## Task 4: `simulate_one_day` (12 points)
- Updates all individuals in the city using `advance_person` (7 pts).
- Returns a new list with correct states for all individuals (5 pts).
  - Partial credit (3 pts): Updates list but incorrectly applies `advance_person` logic.

---

## Task 5: `run_simulation` (12 points)
- Continues simulation until stopping condition (no infected individuals) is met (6 pts).
- Returns both the final state of the city and the correct number of days simulated (6 pts).
  - Partial credit (4 pts): Stops simulation too early or misses returning both required outputs.

---

## Additional Points (8 points)
- **Code readability and comments (4 pts):**
  - Well-commented, clear, and easy-to-read code (4 pts).
  - Partial credit (2 pts): Some comments but incomplete or code readability could be improved.
- **Passing all test cases (4 pts):**
  - Passes all provided test cases (4 pts).
  - Partial credit (2-3 pts): Passes some test cases but fails on edge cases or specific inputs.

---

### Total: 65 points
