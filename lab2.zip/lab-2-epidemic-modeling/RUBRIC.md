# Grading Rubric

## Task 1: `count_infected` (10 points)
- Correctly counts all infected states (`I0`, `I1`, etc.) in the city (10 pts).
  - Partial credit (5 pts): Attempts logic but misses edge cases or incorrect counting.

---

## Task 2: `has_infected_neighbor` (12 points)
- Handles edge cases (first and last person) correctly (6 pts).
- Identifies infected neighbors accurately for all positions (6 pts).
  - Partial credit (3 pts): Correctly identifies neighbors for some positions but not others.

---

## Task 3: `advance_person` (18 points)
- Correctly advances susceptible (`S`) to infected (`I0`) states when appropriate (6 pts).
- Advances infected states (`I0` → `I1` → etc.) correctly based on `days_contagious` (8 pts).
- Handles recovery state (`R`) correctly (4 pts).
  - Partial credit (3 pts): Handles some transitions but not all edge cases.

---

## Task 4: `simulate_one_day` (15 points)
- Updates all individuals in the city using `advance_person` (9 pts).
- Returns a new list with correct states for all individuals (6 pts).
  - Partial credit (3 pts): Updates list but incorrectly applies `advance_person` logic.

---

## Task 5: `run_simulation` (10 points)
- Continues simulation until stopping condition (no infected individuals) is met (5 pts).
- Returns both the final state of the city and the correct number of days simulated (5 pts).
  - Partial credit (3 pts): Stops simulation too early or misses returning both required outputs.

---

### Total: 65 points
