# Grading Rubric

## Task 1: `display_board` (10 points)
- Correctly displays the board in the specified format (10 pts).
  - Partial credit (5 pts): Displays the board but formatting (e.g., separators) is incorrect.

---

## Task 2: `is_valid_move` (12 points)
- Returns `True` for valid moves (6 pts).
- Returns `False` for invalid moves (6 pts), including:
  - Out-of-bounds positions (3 pts).
  - Already occupied positions (3 pts).

---

## Task 3: `make_move` (15 points)
- Correctly updates the board with the player's move (8 pts).
- Ensures no unintended changes to other parts of the board (4 pts).
- Validates the player’s symbol (`'X'` or `'O'`) before updating (3 pts).
  - Partial credit (2 pts): Updates the board but doesn’t validate the player’s symbol.

---

## Task 4: `check_winner` (18 points)
- Detects horizontal wins correctly (6 pts).
- Detects vertical wins correctly (6 pts).
- Detects diagonal wins correctly (6 pts).
  - Partial credit (3 pts): Handles some win conditions but misses others.

---

## Task 5: `is_tie` (10 points)
- Correctly identifies a tie when the board is full and no player has won (6 pts).
- Returns `False` if there are empty spaces or a winner exists (4 pts).
  - Partial credit (3 pts): Handles some scenarios but misses edge cases.

---

## Task 6: `main` (25 points)
- Alternates turns between players correctly (5 pts).
- Validates user input (e.g., row and column indices) (5 pts).
- Calls appropriate helper functions (`is_valid_move`, `make_move`, `check_winner`, etc.) (5 pts).
- Stops the game and displays the winner or tie message correctly (5 pts).
- Displays the final board state at the end of the game (5 pts).
  - Partial credit (3 pts): Implements most of the game loop but misses some functionality.

---

### Total: 90 points
