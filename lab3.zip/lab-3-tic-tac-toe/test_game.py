import pytest
from game import (
    display_board,
    is_valid_move,
    make_move,
    check_winner,
    is_tie,
)

# Task 1: Test display_board
def test_display_board(capsys):
    board = [
        ['X', 'O', 'X'],
        [' ', 'X', 'O'],
        ['O', ' ', 'X']
    ]
    display_board(board)
    captured = capsys.readouterr()
    expected_output = (
        " X | O | X \n"
        "---|---|---\n"
        "   | X | O \n"
        "---|---|---\n"
        " O |   | X \n"
    )
    assert captured.out == expected_output

# Task 2: Test is_valid_move
def test_is_valid_move():
    board = [
        ['X', 'O', 'X'],
        [' ', 'X', 'O'],
        ['O', ' ', 'X']
    ]
    # Valid moves
    assert is_valid_move(board, 1, 0) is True
    assert is_valid_move(board, 2, 1) is True

    # Invalid moves (already occupied)
    assert is_valid_move(board, 0, 0) is False
    assert is_valid_move(board, 1, 2) is False

    # Invalid moves (out of bounds)
    assert is_valid_move(board, 3, 0) is False
    assert is_valid_move(board, -1, 1) is False

# Task 3: Test make_move
def test_make_move():
    board = create_empty_board()
    make_move(board, 0, 0, 'X')
    assert board[0][0] == 'X'

    make_move(board, 1, 1, 'O')
    assert board[1][1] == 'O'

    # Ensure no unintended changes
    assert board[0][1] == ' '
    assert board[2][2] == ' '

# Task 4: Test check_winner
def test_check_winner():
    # Horizontal win
    board = [
        ['X', 'X', 'X'],
        ['O', 'O', ' '],
        [' ', ' ', ' ']
    ]
    assert check_winner(board) == 'X'

    # Vertical win
    board = [
        ['X', 'O', ' '],
        ['X', 'O', ' '],
        ['X', ' ', ' ']
    ]
    assert check_winner(board) == 'X'

    # Diagonal win
    board = [
        ['X', 'O', ' '],
        ['O', 'X', ' '],
        [' ', ' ', 'X']
    ]
    assert check_winner(board) == 'X'

    # No winner
    board = [
        ['X', 'O', 'X'],
        ['O', 'X', 'O'],
        ['O', 'X', 'O']
    ]
    assert check_winner(board) == 'None'

# Task 5: Test is_tie
def test_is_tie():
    # Tie case
    board = [
        ['X', 'O', 'X'],
        ['O', 'X', 'O'],
        ['O', 'X', 'O']
    ]
    assert is_tie(board) is True

    # Not a tie (empty space)
    board = [
        ['X', 'O', 'X'],
        ['O', 'X', ' '],
        ['O', 'X', 'O']
    ]
    assert is_tie(board) is False

    # Not a tie (winner exists)
    board = [
        ['X', 'X', 'X'],
        ['O', 'O', ' '],
        [' ', ' ', ' ']
    ]
    assert is_tie(board) is False

