# Task 1: Display the Board
def display_board(board):
    """
    Displays the current state of the Tic Tac Toe board in a readable format:

         X | O | X 
        ---|---|---
           | X | O
        ---|---|---
         O |   | X

    :param board (list): A 3x3 2D list representing the game board.
    :return (None): Prints the current state of the board.
    """
    pass

# Task 2: Validate the Move
def is_valid_move(board, row, col):
    """
    Checks if a move is valid. A move is valid if the position is within bounds
    and the cell is empty (' ').

    :param board (list): A 3x3 2D list representing the game board.
    :param row (int): The row index of the move.
    :param col (int): The column index of the move.
    :return (bool): True if the move is valid, False otherwise.
    """
    pass

# Task 3: Make the Move
def make_move(board, row, col, player):
    """
    Updates the board with the player's move.

    :param board (list): A 3x3 2D list representing the game board.
    :param row (int): The row index of the move.
    :param col (int): The column index of the move.
    :param player (str): The player's symbol ('X' or 'O').
    :return (None): Updates the board in place.
    """
    pass

# Task 4: Check for a Winner
def check_winner(board):
    """
    Checks if a player has won the game. A player wins if they have three of
    their symbols in a row, column, or diagonal.

    :param board (list): A 3x3 2D list representing the game board.
    :return (str): 'X' if player X wins, 'O' if player O wins, 'None' otherwise.
    """
    pass

# Task 5: Check for a Tie
def is_tie(board):
    """
    Checks if the game has ended in a tie. A tie occurs if the board is full
    and no player has won.

    :param board (list): A 3x3 2D list representing the game board.
    :return (bool): True if the game is a tie, False otherwise.
    """
    pass

# Task 6: Main Game Loop
def main(board):
    """
    The main game loop for Tic Tac Toe. Manages the game flow, alternates turns
    between two players, and checks for a winner or tie after each move.

    :return (None): Prints the game result and manages the game flow.
    """
    pass

# Entry Point of the Script
if __name__ == "__main__":
    board = [
        [' ', ' ', ' '],
        [' ', ' ', ' '],
        [' ', ' ', ' ']
    ]

    main(board)
