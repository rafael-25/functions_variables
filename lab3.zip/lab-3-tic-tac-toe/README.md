# Lab Assignment: Tic Tac Toe

## Learning Objectives and Standards

**Objective:** Build a two-player Tic Tac Toe game in Python to practice 2D lists, loops, conditionals, and functions.

This lab aligns with the following standards:

- **AAP-1.A:** Represent a value with a variable.
- **AAP-1.B:** Determine the value of a variable as a result of an assignment.
- **AAP-2.A:** Represent a process with flowcharts and pseudocode.
- **AAP-2.B:** Represent a step-by-step algorithmic process using sequential code statements.
- **AAP-3.B:** Use appropriate data structures to represent a game board.

By completing this lab, you will:
1. Practice using **variables** and **2D lists** to represent a game board (AAP-1.A, AAP-3.B).
2. Use **loops** and **conditionals** to control the game flow (AAP-2.B).
3. Develop algorithms to check the game's status (e.g., win, tie, or ongoing) (AAP-2.A).

---

## Overview

In this lab, you will create a **Tic Tac Toe** game for two players. Players take turns marking `X` or `O` on a 3x3 grid. The winner is the first to align three of their marks horizontally, vertically, or diagonally. If all spots are filled and no player has aligned three marks, the game ends in a tie.

### The Game Board

The board is represented as a **2D list**:
```python
board = [
    [' ', ' ', ' '],
    [' ', ' ', ' '],
    [' ', ' ', ' ']
]
```
Each position is identified by its row and column indices, ranging from 0 to 2.

## Tasks

You will implement several functions to manage the game's flow, check its status, and interact with players. Finally, you will integrate these functions into a complete Tic Tac Toe game.

### Task 1: `display_board(board)`

#### Description
Write a function to display the current state of the Tic Tac Toe board. Use `print()` statements to format the grid for easy readability.

#### Input
- `board`: A 2D list representing the game board.

#### Output
- None. The function should print the formatted board.

#### Example
```python
board = [
    ['X', ' ', 'O'],
    [' ', 'X', ' '],
    ['O', ' ', 'X']
]

display_board(board)

# The formatted board
 X |   | O
-----------
   | X |
-----------
 O |   | X
```
### Task 2: `is_valid_move(board, row, col)`

#### Description
Write a function to check if a move is valid. A move is valid if:
1. The row and column are within the bounds of the board (0 to 2).
2. The specified position on the board is empty (`' '`).

#### Input
- `board`: A 2D list representing the game board.
- `row` and `col`: Integers representing the row and column of the move.

#### Output
- A boolean value:
  - `True` if the move is valid.
  - `False` otherwise.

#### Example
```python
board = [
    ['X', ' ', 'O'],
    [' ', 'X', ' '],
    ['O', ' ', 'X']
]

is_valid_move(board, 0, 1)  # Output: True
is_valid_move(board, 1, 1)  # Output: False
is_valid_move(board, 3, 0)  # Output: False
```
### Task 3: `make_move(board, row, col, player)`

#### Description
Write a function to update the board with a player's move.

#### Input
- `board`: A 2D list representing the game board.
- `row` and `col`: Integers representing the row and column of the move.
- `player`: A string (`'X'` or `'O'`) representing the current player.

#### Output
- None. The function should update the board in place.

#### Example
```python
board = [
    ['X', ' ', 'O'],
    [' ', 'X', ' '],
    ['O', ' ', 'X']
]

make_move(board, 1, 2, 'O')

# The updated board:
# [
#     ['X', ' ', 'O'],
#     [' ', 'X', 'O'],
#     ['O', ' ', 'X']
# ]
```

### Task 4: `check_winner(board)`

#### Description
Write a function to check if a player has won. A player wins if they align three of their marks horizontally, vertically, or diagonally.

#### Input
- `board`: A 2D list representing the game board.

#### Output
- A string:
  - `'X'` if player X wins.
  - `'O'` if player O wins.
  - `'None'` if there is no winner.

#### Example
```python
board_1 = [
    ['X', 'X', 'X'],
    ['O', ' ', 'O'],
    [' ', 'O', ' ']
]

check_winner(board_1)  # Output: 'X'

board_2 = [
    ['X', 'O', 'X'],
    ['X', 'O', ' '],
    ['O', 'O', 'X']
]

check_winner(board_2)  # Output: 'O'

board_3 = [
    ['X', 'O', 'X'],
    ['O', 'X', 'O'],
    ['O', 'X', 'O']
]

check_winner(board_3)  # Output: 'None'
```

### Task 5: `is_tie(board)`

#### Description
Write a function to check if the game has ended in a tie. A tie occurs if the board is full and no player has won.

#### Input
- `board`: A 2D list representing the game board.

#### Output
- A boolean value:
  - `True` if the game is a tie.
  - `False` otherwise.

#### Example
```python
board_1 = [
    ['X', 'O', 'X'],
    ['O', 'X', 'O'],
    ['O', 'X', 'O']
]

is_tie(board_1)  # Output: True

board_2 = [
    ['X', 'O', ' '],
    ['O', 'X', 'O'],
    ['O', 'X', 'O']
]

is_tie(board_2)  # Output: False

board_3 = [
    ['X', 'X', 'X'],
    ['O', 'O', 'X'],
    ['X', 'O', 'O']
]

is_tie(board_3)  # Output: False
```
### Task 6: `main()`

#### Description
Write the main function to manage the game loop, where two players alternate turns until there is a winner or the game ends in a tie.

#### Details
1. **Display Instructions**:
   - Print a welcome message and instructions on how to play.

2. **Initialize the Board**:
   - Create a 3x3 board as a 2D list filled with spaces (`' '`).

3. **Game Loop**:
   - Alternate between Player X and Player O.
   - Display the current state of the board using `display_board()`.
   - Prompt the current player to input their move (row and column).
   - Validate the move using `is_valid_move()`:
     - If valid, update the board with `make_move()`.
     - If invalid, prompt the player to try again.
   - Check for a winner using `check_winner()`:
     - If a winner is found, display a win message and end the game.
   - Check for a tie using `is_tie()`:
     - If the game is a tie, display a tie message and end the game.

4. **End of Game**:
   - Print the final board and a goodbye message.

#### Example Game
```python
# Starting the game:
Welcome to Tic Tac Toe!
Player X, you will go first.

   |   |
-----------
   |   |
-----------
   |   |

Player X, enter your move (row and column): 0 0

 X |   |
-----------
   |   |
-----------
   |   |

Player O, enter your move (row and column): 1 1

 X |   |
-----------
   | O |
-----------
   |   |

Player X, enter your move (row and column): 0 1

 X | X |
-----------
   | O |
-----------
   |   |

Player O, enter your move (row and column): 2 1

 X | X |
-----------
   | O |
-----------
   | O |

Player X, enter your move (row and column): 0 2

 X | X | X
-----------
   | O |
-----------
   | O |

Player X wins!
```
