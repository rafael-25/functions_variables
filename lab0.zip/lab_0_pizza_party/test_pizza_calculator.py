from pizza_calculator import calculate_pizzas, serving_size, calculate_cost
import pytest

def test_calculate_pizzas():
    """
    Test the calculate_pizzas function with 9, 12, and 25 guests.
    """
    assert calculate_pizzas(9) == (1, 0, 2)
    assert calculate_pizzas(12) == (1, 1, 0)
    assert calculate_pizzas(25) == (3, 1, 0)

def test_serving_size():
    """
    Test the serving_size function with various combinations of pizzas.
    """
    assert pytest.approx(serving_size(1, 2, 0), 0.01) == 804.25
    assert pytest.approx(serving_size(1, 0, 2), 0.01) == 452.16
    assert pytest.approx(serving_size(3, 1, 0), 0.01) == 1570.80

def test_calculate_cost():
    """
    Test the calculate_cost function with various pizza counts and tip percentages.
    """
    assert pytest.approx(calculate_cost(1, 0, 2, 15), 0.01) == 33.63
    assert pytest.approx(calculate_cost(1, 1, 0, 10), 0.01) == 41.94
    assert pytest.approx(calculate_cost(3, 1, 0, 20), 0.01) == 88.85
