import pytest
from wordle import get_player_guess, has_won, give_feedback, display_game_state
from unittest.mock import patch

# Test for has_won
def test_has_won_correct_guess():
    assert has_won("crypt", "crypt") == True
    assert has_won("crypt", "crane") == False
    assert has_won("crypt", "cry") == False

# Test for give_feedback
def test_give_feedback_all_correct():
    assert give_feedback("crypt", "crypt") == "🟩🟩🟩🟩🟩"
    assert give_feedback("crypt", "crane") == "🟩🟩⬜⬜⬜"
    assert give_feedback("crypt", "clasp") == "🟩⬜⬜⬜🟨"
    assert give_feedback("crypt", "stare") == "⬜🟨⬜🟨⬜"
    assert give_feedback("crypt", "apple") == "⬜🟨🟨⬜⬜"
    assert give_feedback("crypt", "smile") == "⬜⬜⬜⬜⬜"

# Test for display_game_state
def test_display_game_state_full_correct(capsys):
    display_game_state("crypt", "🟩🟩🟩🟩🟩")
    captured = capsys.readouterr()
    assert captured.out.strip() == "CRYPT | 🟩🟩🟩🟩🟩"

def test_display_game_state_partial_correct(capsys):
    display_game_state("crane", "🟩⬜⬜⬜⬜")
    captured = capsys.readouterr()
    assert captured.out.strip() == "CRANE | 🟩⬜⬜⬜⬜"

# Test for get_player_guess()
@patch('builtins.input')
def test_get_player_guess_valid_input(mock_input):
    mock_input.side_effect = ['crane']
    assert get_player_guess() == 'crane'

@patch('builtins.input')
def test_get_player_guess_invalid_length(mock_input):
    mock_input.side_effect = ['shorts', 'crane']
    assert get_player_guess() == 'crane'

@patch('builtins.input')
def test_get_player_guess_invalid_chars(mock_input):
    mock_input.side_effect = ['12345', 'crane']
    assert get_player_guess() == 'crane'

@patch('builtins.input')
def test_get_player_guess_invalid_word(mock_input):
    mock_input.side_effect = ['xyzpq', 'crane']
    assert get_player_guess() == 'crane'
