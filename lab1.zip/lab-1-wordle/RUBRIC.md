## Grading Rubric

### Task 1: `get_player_guess` (15 points)

* **Correct Input Validation:** (10 points)
  * Validates input length (5 characters).
  * Validates input characters (only letters).
  * Validates word existence in the wordlist.
* **Clear Error Messages:** (3 points)
  * Provides informative error messages for invalid inputs.
* **Efficient Looping:** (2 points)
  * Uses a `while` loop to continuously prompt for input until a valid guess is received.

### Task 2: `has_won` (5 points)
* **Correct Win Condition:** (5 points)
  * Accurately compares the secret word and the guess.
  * Returns `True` if they match, `False` otherwise.

### Task 3: `give_feedback` (15 points)
* **Correct Feedback Generation:** (10 points)
  * Accurately identifies correct letters in correct positions (green squares).
  * Accurately identifies correct letters in incorrect positions (yellow squares).
  * Accurately identifies incorrect letters (gray squares).
* **Clear Feedback Format:** (5 points)
  * Returns feedback as a string of emoji symbols.

### Task 4: `display_game_state` (5 points)
* **Correct Formatting:** (5 points)
  * Displays the guess and feedback in the specified format: `<GUESS> | <FEEDBACK>`.

### Task 5: `play_wordle` (20 points)
* **Game Loop:** (5 points)
  * Implements a `while` loop to control the number of attempts.
  * Breaks the loop when the player wins or reaches the maximum number of attempts.
* **Function Integration:** (5 points)
  * Correctly calls `get_player_guess`, `has_won`, `give_feedback`, and `display_game_state`.
* **Win/Loss Conditions:** (5 points)
  * Handles win and loss conditions appropriately.
  * Displays appropriate messages to the user.
* **Game Flow:** (5 points)
  * Ensures smooth game flow and clear user instructions.

### Total Points: 60
